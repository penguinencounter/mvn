package org.figuramc.figura.ducks;

import net.minecraft.client.renderer.SubmitNodeStorage;

import java.util.List;

public interface StorageExtension {
    List<SubmitNodeStorage.NameTagSubmit> getOutlineSubmits();
}
