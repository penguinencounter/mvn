package org.figuramc.fsb2.server.versioned.mixin;

import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.figuramc.fsb2.api.PlayerInfo;
import org.figuramc.fsb2.api.config.ServerIdentification;
import org.figuramc.fsb2.api.except.FSBArgumentException;
import org.figuramc.fsb2.api.packets.s2c.S2CHelloPacket;
import org.figuramc.fsb2.server.FSB;
import org.figuramc.fsb2.server.ServerSession;
import org.figuramc.fsb2.server.internals.NetworkingService;
import org.figuramc.fsb2.server.versioned.VersionedNetworking;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow
    @Final
    private MinecraftServer server;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void afterPlayBegins(MinecraftServer server, Connection connection, ServerPlayer player, CallbackInfo ci) {
        ServerGamePacketListenerImpl that = (ServerGamePacketListenerImpl) (Object) this;
        ServerSession srv = FSB.serverGet(server);
        PlayerInfo info = new PlayerInfo(player.getUUID(), player.getName().getString());
        try {
            srv.newRemote(that, info);
            VersionedNetworking netSvc = (VersionedNetworking) NetworkingService.SERVICE;
            srv.scheduler.countDown(
                    () -> netSvc.send(that, new S2CHelloPacket(ServerIdentification.defaultValues())),
                    5
            );
        } catch (FSBArgumentException ignored) {

        }
    }

    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void beforeDisconnect(Component reason, CallbackInfo ci) {
        ServerGamePacketListenerImpl that = (ServerGamePacketListenerImpl) (Object) this;
        ServerSession srv = FSB.serverGet(server);
        srv.delRemote(that);
    }
}
