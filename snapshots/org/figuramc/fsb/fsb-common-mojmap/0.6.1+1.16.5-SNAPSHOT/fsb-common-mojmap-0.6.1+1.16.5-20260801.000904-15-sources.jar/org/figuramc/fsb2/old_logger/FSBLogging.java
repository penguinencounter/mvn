package org.figuramc.fsb2.old_logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.figuramc.fsb2.server.FSB;
import org.figuramc.fsb2.services.FSBLoggingService;

public class FSBLogging implements FSBLoggingService {
    @SuppressWarnings("LoggerInitializedWithForeignClass")
    public static final Logger LOGGER = LogManager.getLogger(FSB.class);

    @Override
    public Object getLogger() {
        return LOGGER;
    }
}
