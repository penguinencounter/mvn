package org.figuramc.fsb2.server;

import org.figuramc.fsb2.api.PlayerSession;
import org.figuramc.fsb2.api.packets.Packet;
import org.figuramc.fsb2.api.packets.c2s.C2SBeginUploadPacket;
import org.figuramc.fsb2.api.packets.transfer.TransferOpenPacket;
import org.figuramc.fsb2.api.utils.ImmediateEventSystem;
import org.figuramc.fsb2.api.utils.ImmediateEventSystem.ReturnableEventBus;

import java.util.function.Consumer;

public class FSBServerEvents {
    /**
     * This field exists <b>purely as a helper for addon developers.</b> By default, events run on the network thread.
     * Before blocking on the main thread, make sure you are not on the main thread already.
     */
    public final Consumer<Runnable> runOnMainThread;

    public FSBServerEvents(Consumer<Runnable> runOnMainThread) {
        super();
        this.runOnMainThread = runOnMainThread;
    }

    public static <T extends Packet<?>> SimplePacketWrapEvent<T> wrap(T packet, PlayerSession player) {
        return new SimplePacketWrapEvent<>(packet, player);
    }

    public static class SimplePacketWrapEvent<T extends Packet<?>> extends ImmediateEventSystem.Event {
        public final T packet;
        public final PlayerSession player;


        public SimplePacketWrapEvent(T packet, PlayerSession player) {
            this.packet = packet;
            this.player = player;
        }
    }

    public ReturnableEventBus<SimplePacketWrapEvent<TransferOpenPacket>, ServerSession, Boolean> BEFORE_ANY_TRANSFER = new ReturnableEventBus<>();
    public ReturnableEventBus<SimplePacketWrapEvent<TransferOpenPacket>, ServerSession, Boolean> BEFORE_UPLOAD_TRANSFER = new ReturnableEventBus<>();
    public ReturnableEventBus<SimplePacketWrapEvent<C2SBeginUploadPacket>, ServerSession, Boolean> BEFORE_UPLOAD_BEGINS = new ReturnableEventBus<>();
}
